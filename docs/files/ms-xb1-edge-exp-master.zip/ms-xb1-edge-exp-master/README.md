# ms-xb1-edge-exp

For Xbox-SystemOS version: 10.0.14393.2152 (rs1_xbox_rel_1610 161208-1218) fre, 12/14/2016

Other versions will most likely need modifications to the script. 

Credits:

https://github.com/theori-io/chakra-2016-11

https://bugs.chromium.org/p/project-zero/issues/detail?id=952

https://bugs.chromium.org/p/project-zero/issues/detail?id=945
